<?php
	//require_once('getMovies.php');
	require_once('read.php');
	//require_once('login.php');
	//require_once('sessions.php');
	//require_once('user.php');
?>